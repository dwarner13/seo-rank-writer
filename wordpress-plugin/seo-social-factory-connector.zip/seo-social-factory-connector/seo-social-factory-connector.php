<?php
/**
 * Plugin Name: SEO Social Factory Connector
 * Plugin URI: https://seosocialfactory.com
 * Description: Receives SEO content from the SEO Social Factory app, saves meta fields, and outputs SEO tags in the page head.
 * Version: 1.0.0
 * Author: SEO Social Factory
 * License: GPL-2.0-or-later
 * Text Domain: seo-social-factory
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SSF_VERSION', '1.0.0' );
define( 'SSF_OPTION_API_KEY', 'ssf_api_key' );
define( 'SSF_OPTION_LAST_CONNECTED', 'ssf_last_connected' );
define( 'SSF_OPTION_LAST_DRAFT', 'ssf_last_draft' );
define( 'SSF_OPTION_LAST_ERROR', 'ssf_last_error' );

/* ================================================================
   1. ACTIVATION — generate API key
   ================================================================ */

function ssf_activate() {
	if ( ! get_option( SSF_OPTION_API_KEY ) ) {
		update_option( SSF_OPTION_API_KEY, wp_generate_password( 40, false ) );
	}
}
register_activation_hook( __FILE__, 'ssf_activate' );

/* ================================================================
   2. REGISTER CUSTOM META FIELDS
   ================================================================ */

function ssf_register_meta_fields() {
	$post_types = array( 'post', 'page' );
	$fields     = array(
		'_ssf_meta_title',
		'_ssf_meta_description',
		'_ssf_focus_keyword',
		'_ssf_schema_json',
		'_ssf_og_title',
		'_ssf_og_description',
		'_ssf_og_image',
	);

	foreach ( $post_types as $post_type ) {
		foreach ( $fields as $key ) {
			register_post_meta(
				$post_type,
				$key,
				array(
					'show_in_rest'  => true,
					'single'        => true,
					'type'          => 'string',
					'auth_callback' => function () {
						return current_user_can( 'edit_posts' );
					},
				)
			);
		}
	}
}
add_action( 'init', 'ssf_register_meta_fields' );

/* ================================================================
   3. ADMIN MENU PAGE
   ================================================================ */

function ssf_admin_menu() {
	add_menu_page(
		'SEO Social Factory',
		'SEO Social Factory',
		'manage_options',
		'seo-social-factory',
		'ssf_admin_page',
		'dashicons-share-alt',
		80
	);
}
add_action( 'admin_menu', 'ssf_admin_menu' );

function ssf_admin_page() {
	// Handle regenerate key
	if (
		isset( $_POST['ssf_regenerate_key'] ) &&
		check_admin_referer( 'ssf_regenerate_key_action', 'ssf_nonce' )
	) {
		update_option( SSF_OPTION_API_KEY, wp_generate_password( 40, false ) );
		echo '<div class="notice notice-success"><p>API key regenerated.</p></div>';
	}

	$api_key        = get_option( SSF_OPTION_API_KEY, '' );
	$endpoint_url   = rest_url( 'seo-social-factory/v1/create-draft' );

	?>
	<div class="wrap">
		<h1>SEO Social Factory Connector</h1>

		<div class="card" style="max-width:700px;margin-top:20px;padding:20px;">
			<h2>Connection Details</h2>
			<table class="form-table">
				<tr>
					<th>Endpoint URL</th>
					<td>
						<code style="display:block;padding:8px;background:#f0f0f0;border-radius:4px;word-break:break-all;">
							<?php echo esc_html( $endpoint_url ); ?>
						</code>
					</td>
				</tr>
				<tr>
					<th>API Key</th>
					<td>
						<code style="display:block;padding:8px;background:#f0f0f0;border-radius:4px;word-break:break-all;">
							<?php echo esc_html( $api_key ); ?>
						</code>
					</td>
				</tr>
			</table>

			<form method="post" style="margin-top:10px;">
				<?php wp_nonce_field( 'ssf_regenerate_key_action', 'ssf_nonce' ); ?>
				<button type="submit" name="ssf_regenerate_key" class="button">Regenerate API Key</button>
			</form>
		</div>

		<div class="card" style="max-width:700px;margin-top:20px;padding:20px;">
			<h2>How to Connect</h2>
			<ol style="margin-left:20px;line-height:2;">
				<li>Open the SEO Social Factory app.</li>
				<li>Go to the <strong>WordPress</strong> tab.</li>
				<li>Enter your <strong>site URL</strong>: <code><?php echo esc_html( home_url() ); ?></code></li>
				<li>Paste the <strong>API Key</strong> shown above into the app.</li>
				<li>Click <strong>Test Connection</strong> to verify.</li>
				<li>Generate your SEO content and click <strong>Send to WordPress</strong>.</li>
			</ol>
		</div>

		<div class="card" style="max-width:700px;margin-top:20px;padding:20px;">
			<h2>What This Plugin Does</h2>
			<ul style="margin-left:20px;line-height:2;">
				<li>Receives SEO content via a secure REST API endpoint.</li>
				<li>Creates a draft page or post with the article body.</li>
				<li>Saves SEO meta title, description, focus keyword, and schema separately.</li>
				<li>Outputs <code>&lt;title&gt;</code>, meta description, Open Graph tags, and schema JSON-LD in the page head.</li>
				<li>No dependency on RankMath, Yoast, or any other SEO plugin.</li>
			</ul>
		</div>
	</div>
	<?php
}

/* ================================================================
   4. REST API ENDPOINT
   ================================================================ */

function ssf_register_rest_routes() {
	register_rest_route(
		'seo-social-factory/v1',
		'/create-draft',
		array(
			'methods'             => 'POST',
			'callback'            => 'ssf_handle_create_draft',
			'permission_callback' => 'ssf_verify_api_key',
		)
	);

	register_rest_route(
		'seo-social-factory/v1',
		'/test',
		array(
			'methods'             => 'GET',
			'callback'            => 'ssf_handle_test',
			'permission_callback' => 'ssf_verify_api_key',
		)
	);
}
add_action( 'rest_api_init', 'ssf_register_rest_routes' );

/**
 * Verify the X-SSF-API-Key header.
 */
function ssf_verify_api_key( $request ) {
	$provided = $request->get_header( 'X-SSF-API-Key' );
	$stored   = get_option( SSF_OPTION_API_KEY, '' );

	if ( empty( $stored ) || empty( $provided ) ) {
		return new WP_Error( 'ssf_unauthorized', 'Missing API key.', array( 'status' => 401 ) );
	}

	if ( ! hash_equals( $stored, $provided ) ) {
		return new WP_Error( 'ssf_unauthorized', 'Invalid API key.', array( 'status' => 401 ) );
	}

	return true;
}

/**
 * Test endpoint — confirms the connection works.
 */
function ssf_handle_test( $request ) {
	update_option( SSF_OPTION_LAST_CONNECTED, current_time( 'mysql' ) );
	delete_option( SSF_OPTION_LAST_ERROR );

	return rest_ensure_response(
		array(
			'ok'      => true,
			'site'    => home_url(),
			'name'    => get_bloginfo( 'name' ),
			'version' => SSF_VERSION,
		)
	);
}

/**
 * Create a draft post/page with SEO meta fields.
 */
function ssf_handle_create_draft( $request ) {
	$params = $request->get_json_params();

	$title       = sanitize_text_field( $params['title'] ?? '' );
	$content     = wp_kses_post( $params['content'] ?? '' );
	$status      = 'draft';
	$post_type   = ( $params['postType'] ?? 'page' ) === 'post' ? 'post' : 'page';
	$excerpt     = sanitize_text_field( $params['excerpt'] ?? '' );

	if ( empty( $content ) ) {
		return new WP_Error( 'ssf_no_content', 'No content provided.', array( 'status' => 400 ) );
	}

	// Create the post
	$post_id = wp_insert_post(
		array(
			'post_title'   => $title,
			'post_content' => $content,
			'post_excerpt' => $excerpt,
			'post_status'  => $status,
			'post_type'    => $post_type,
		),
		true
	);

	if ( is_wp_error( $post_id ) ) {
		update_option( SSF_OPTION_LAST_ERROR, $post_id->get_error_message() . ' (' . current_time( 'mysql' ) . ')' );
		return new WP_Error(
			'ssf_insert_failed',
			$post_id->get_error_message(),
			array( 'status' => 500 )
		);
	}

	// Save SEO meta fields
	$meta_fields = array(
		'_ssf_meta_title'       => sanitize_text_field( $params['metaTitle'] ?? '' ),
		'_ssf_meta_description' => sanitize_text_field( $params['metaDescription'] ?? '' ),
		'_ssf_focus_keyword'    => sanitize_text_field( $params['focusKeyword'] ?? '' ),
		'_ssf_schema_json'      => $params['schemaJson'] ?? '',
		'_ssf_og_title'         => sanitize_text_field( $params['ogTitle'] ?? '' ),
		'_ssf_og_description'   => sanitize_text_field( $params['ogDescription'] ?? '' ),
		'_ssf_og_image'         => esc_url_raw( $params['ogImage'] ?? '' ),
	);

	foreach ( $meta_fields as $key => $value ) {
		if ( ! empty( $value ) ) {
			update_post_meta( $post_id, $key, $value );
		}
	}

	// Log activity
	update_option( SSF_OPTION_LAST_CONNECTED, current_time( 'mysql' ) );
	update_option( SSF_OPTION_LAST_DRAFT, wp_json_encode( array(
		'id'    => $post_id,
		'title' => $title,
		'type'  => $post_type,
		'time'  => current_time( 'mysql' ),
	) ) );
	delete_option( SSF_OPTION_LAST_ERROR );

	// Build response
	$edit_link = admin_url( "post.php?post={$post_id}&action=edit" );

	return rest_ensure_response(
		array(
			'ok'       => true,
			'id'       => $post_id,
			'link'     => get_permalink( $post_id ),
			'editLink' => $edit_link,
			'type'     => $post_type,
			'status'   => $status,
		)
	);
}

/* ================================================================
   5. FRONTEND HEAD OUTPUT
   ================================================================ */

/**
 * Override the document title with _ssf_meta_title when available.
 */
function ssf_override_document_title( $title ) {
	if ( ! is_singular() ) {
		return $title;
	}

	$ssf_title = get_post_meta( get_the_ID(), '_ssf_meta_title', true );
	if ( ! empty( $ssf_title ) ) {
		return esc_html( $ssf_title );
	}

	return $title;
}
add_filter( 'pre_get_document_title', 'ssf_override_document_title', 20 );

/**
 * Output SEO meta, Open Graph, and Schema JSON-LD in <head>.
 */
function ssf_output_head_meta() {
	if ( ! is_singular() ) {
		return;
	}

	$post_id = get_the_ID();

	$meta_desc   = get_post_meta( $post_id, '_ssf_meta_description', true );
	$og_title    = get_post_meta( $post_id, '_ssf_og_title', true );
	$og_desc     = get_post_meta( $post_id, '_ssf_og_description', true );
	$og_image    = get_post_meta( $post_id, '_ssf_og_image', true );
	$schema_json = get_post_meta( $post_id, '_ssf_schema_json', true );

	echo "\n<!-- SEO Social Factory -->\n";

	if ( ! empty( $meta_desc ) ) {
		printf( '<meta name="description" content="%s" />' . "\n", esc_attr( $meta_desc ) );
	}

	if ( ! empty( $og_title ) ) {
		printf( '<meta property="og:title" content="%s" />' . "\n", esc_attr( $og_title ) );
	}
	if ( ! empty( $og_desc ) ) {
		printf( '<meta property="og:description" content="%s" />' . "\n", esc_attr( $og_desc ) );
	}
	if ( ! empty( $og_image ) ) {
		printf( '<meta property="og:image" content="%s" />' . "\n", esc_url( $og_image ) );
	}

	printf( '<meta property="og:type" content="%s" />' . "\n", is_single() ? 'article' : 'website' );
	printf( '<meta property="og:url" content="%s" />' . "\n", esc_url( get_permalink( $post_id ) ) );

	// Twitter Card tags
	echo '<meta name="twitter:card" content="summary_large_image" />' . "\n";
	if ( ! empty( $og_title ) ) {
		printf( '<meta name="twitter:title" content="%s" />' . "\n", esc_attr( $og_title ) );
	}
	if ( ! empty( $og_desc ) ) {
		printf( '<meta name="twitter:description" content="%s" />' . "\n", esc_attr( $og_desc ) );
	}
	if ( ! empty( $og_image ) ) {
		printf( '<meta name="twitter:image" content="%s" />' . "\n", esc_url( $og_image ) );
	}

	if ( ! empty( $schema_json ) ) {
		$decoded = json_decode( $schema_json );
		if ( json_last_error() === JSON_ERROR_NONE ) {
			echo '<script type="application/ld+json">' . "\n";
			echo wp_json_encode( $decoded, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT );
			echo "\n</script>\n";
		}
	}

	echo "<!-- /SEO Social Factory -->\n";
}
add_action( 'wp_head', 'ssf_output_head_meta', 1 );
